from src.portfolio_analysis import calculate_metrics
from src.data_loader import load_sample_data
from src.visualizer import plot_portfolio

def main():
    returns = load_sample_data()
    metrics = calculate_metrics(returns)
    print("Portfolio Metrics:")
    for k, v in metrics.items():
        print(f"{k}: {v:.2f}")
    plot_portfolio(returns)

if __name__ == "__main__":
    main()
