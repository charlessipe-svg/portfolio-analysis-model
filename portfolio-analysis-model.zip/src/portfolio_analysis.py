import numpy as np
import pandas as pd

def calculate_metrics(returns_df):
    mean_returns = returns_df.mean()
    cov_matrix = returns_df.cov()
    weights = np.array([1 / len(mean_returns)] * len(mean_returns))

    portfolio_return = np.dot(weights, mean_returns)
    portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    sharpe_ratio = portfolio_return / portfolio_volatility

    return {
        "Expected Return": portfolio_return * 252,
        "Volatility": portfolio_volatility * (252 ** 0.5),
        "Sharpe Ratio": sharpe_ratio * (252 ** 0.5)
    }
