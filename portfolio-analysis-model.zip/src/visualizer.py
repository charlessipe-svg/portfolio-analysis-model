import matplotlib.pyplot as plt

def plot_portfolio(returns_df):
    cumulative_returns = (1 + returns_df).cumprod()
    cumulative_returns.plot(title="Portfolio Cumulative Returns")
    plt.xlabel("Days")
    plt.ylabel("Growth of $1")
    plt.show()
