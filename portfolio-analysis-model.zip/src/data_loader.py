import pandas as pd
import numpy as np

def load_sample_data():
    np.random.seed(42)
    data = np.random.randn(252, 4) / 100  # 4 assets, 252 trading days
    return pd.DataFrame(data, columns=["Stock A", "Stock B", "Stock C", "Stock D"])
