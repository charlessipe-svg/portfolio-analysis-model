# Portfolio Analysis Model

This Python-based finance project simulates portfolio returns, calculates key metrics like expected return, volatility, and Sharpe ratio, and visualizes results.

## Features
- Historical return simulation
- Portfolio optimization (equal-weighted baseline)
- Risk/return visualization
- Modular structure (extensible for more assets or backtesting)

## Files
- `main.py`: Runs the analysis
- `src/portfolio_analysis.py`: Core analytics functions
- `src/data_loader.py`: Handles synthetic or imported data
- `src/visualizer.py`: Plotting and summary tools

## Usage
```bash
python main.py
```

## Example Output
- Portfolio expected return and volatility
- Sharpe ratio
- Risk-return scatter plots

---
Created for portfolio demonstration purposes.
